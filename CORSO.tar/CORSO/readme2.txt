
CIS630, Winter 2019, Term Project II, Due date: June 10, 2019

Please complete the following information, save this file and submit it along with your program

Your First and Last name: Amie Corso
Your Student ID: 951528694

What programming language did you use to write your code?
Java:  therefore the program must be executed as:
"% java ring -c config.txt -i input.txt -o output.txt" (don't forget the java first!)
thank you :) 

your code compiles on ix-dev: Yes

in the absence of node dynamics: 
	your code can form the proper ring:   Yes
	your code is able to conduct an election: Yes
	your code is able to deliver posts from each client to all clients: Yes

when new nodes are added to the ring:
        your code can form the proper ring:   Yes
        your code is able to conduct an election: Yes
        your code is able to deliver posts from each client to all clients: Yes


when nodes are removed from the ring:
        your code can form the proper ring:   Yes
        your code is able to conduct an election: Yes
        your code is able to deliver posts from each client to all clients: Yes
