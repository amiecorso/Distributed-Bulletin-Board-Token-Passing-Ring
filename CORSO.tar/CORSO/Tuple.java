
public class Tuple {
	int port;
	Object packet;
	
	Tuple(int port, Object packet) {
		this.port = port;
		this.packet = packet;
	}
}
