import java.io.Serializable;

public class Packet implements Serializable {
	int type;
	int srcID;
}
